
-- This SQL file will be executed when you deploy or build your project
-- It creates a trigger to send admin notifications when a new profile is created with 'pending' status

-- Function to call the Edge Function that notifies admins
CREATE OR REPLACE FUNCTION public.notify_admin_on_pending_profile()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_email TEXT;
  v_name TEXT;
  v_project_ref TEXT;
  v_anon_key TEXT;
BEGIN
  -- Only trigger for 'pending' status profiles
  IF NEW.status = 'pending' THEN
    -- Get the user's email
    SELECT email INTO v_email FROM auth.users WHERE id = NEW.id;
    
    -- Get user's name
    v_name := NEW.full_name;
    
    -- Get project reference and anon key for authentication
    v_project_ref := 'gtzcjxzllsrtaieopsgc';
    v_anon_key := 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd0emNqeHpsbHNydGFpZW9wc2djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU0MTExMzUsImV4cCI6MjA2MDk4NzEzNX0.JNzTxTkIGWYy8WIwf1DuupBgCil9HzMKLR89AHZp108';
    
    -- Make HTTP request to edge function with authentication
    PERFORM
      net.http_post(
        url:= concat('https://', v_project_ref, '.supabase.co/functions/v1/notify-admin'),
        headers:= json_build_object(
          'Content-Type', 'application/json',
          'Authorization', concat('Bearer ', v_anon_key)
        )::jsonb,
        body:= json_build_object(
          'userId', NEW.id,
          'userEmail', v_email,
          'userName', v_name
        )::text
      );
      
    -- Log the notification attempt
    RAISE NOTICE 'Admin notification triggered for user % (%)', NEW.id, v_email;
  END IF;
  
  RETURN NULL;
END;
$$;

-- Create trigger that runs AFTER a profile is inserted or updated
CREATE OR REPLACE TRIGGER trigger_notify_admin_on_pending_profile
  AFTER INSERT OR UPDATE OF status ON public.profiles
  FOR EACH ROW
  WHEN (NEW.status = 'pending')
  EXECUTE FUNCTION public.notify_admin_on_pending_profile();

-- Enable the pg_net extension if not already enabled (needed for HTTP calls)
CREATE EXTENSION IF NOT EXISTS pg_net;
